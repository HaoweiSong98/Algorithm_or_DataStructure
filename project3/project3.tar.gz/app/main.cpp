#include <iostream>
#include <string>
#include <fstream>
#include <sstream>

#include "proj3.hpp"
#include "Wordset.hpp"

int main()
{    
    return 0;
}

