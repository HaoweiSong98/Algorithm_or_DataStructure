#ifndef __PROJ2_QUEUE_HPP
#define __PROJ2_QUEUE_HPP

#include "runtimeexcept.hpp"

class QueueEmptyException : public RuntimeException 
{
public:
	QueueEmptyException(const std::string & err) : RuntimeException(err) {}
};


template<typename Object>
class LLQueue
{
private:
	struct node{
		Object data;
		node *next = nullptr;
	};
	node *nodefront, *noderear;
	int countnum;
	// fill in private member data here

public:
	LLQueue();

//	These are copy constructors and  assignment operators. 
	// These should be "deep copies" -- copy the contents, not just a pointer to the front. 
	LLQueue(const LLQueue & st);
	LLQueue & operator=(const LLQueue & st);
	~LLQueue()
	{
		// You do need to implement the destructor though.
		if(countnum > 0){
			node *newfront = nodefront;
			while(nodefront->next){
				newfront = nodefront->next;
				delete nodefront;
				countnum -= 1;
				nodefront = newfront;
			}
		}
		
	}

	size_t size() const noexcept;
	bool isEmpty() const noexcept;

	// We have two front() for the same reason the Stack in lecture week 2 had two top() functions.
	// If you do not know why there are two, your FIRST step needs to be to review your notes from that lecture.

	Object & front();
	const Object & front() const;

	void enqueue(const Object & elem);

// does not return anything.  Just removes. 
	void dequeue();
};

// TODO:  Fill in the functions here. 
template<typename Object>
LLQueue<Object>::LLQueue(){
	node *newnode = new node;
	this->nodefront = newnode;
	this->noderear = newnode;
	this->countnum = 0;
}


template<typename Object>
LLQueue<Object>::LLQueue(const LLQueue<Object> & st){
	if(st.isEmpty() == false){
		Object get_data = st.nodefront->data;
		node *changenode = new node;
		changenode->data = get_data;
		changenode->next = NULL;
		this->nodefront = changenode;
		this->noderear = changenode;
		this->countnum = 1;
		node *trackst = st.nodefront;
		while(trackst->next){
			trackst = trackst->next;
			this->enqueue(trackst->data);
			
		}
	}
	

}
template<typename Object>
LLQueue<Object> & LLQueue<Object>::operator=(const LLQueue<Object> & st){
	if(st.isEmpty()){
		node *emptynode = new node;
		this->nodefront = emptynode;
		this->noderear = emptynode;
		countnum = 0;
	}
	else{
		node *emptynode = new node;
		this->nodefront = emptynode;
		this->noderear = emptynode;
		this->enqueue(st.nodefront->data);
		node *trackst1 = st.nodefront;
		while(trackst1->next){
			trackst1 = trackst1->next;
			this->enqueue(trackst1->data);

		}
	}
	return *this;
}
template<typename Object>
size_t LLQueue<Object>::size() const noexcept{
	return countnum;
}

template<typename Object>
bool LLQueue<Object>::isEmpty() const noexcept{
	if(this->countnum == 0){
		return true;
	}
	return false;
}

template<typename Object>
Object & LLQueue<Object>::front(){
	if(isEmpty()){
		throw QueueEmptyException("It's empty");
	}
	return this->nodefront->data;
}



template<typename Object>
const Object & LLQueue<Object>::front() const{
	if(isEmpty()){
		throw QueueEmptyException("It's empty");
	}
	return this->nodefront->data;
}

template<typename Object>
void LLQueue<Object>::enqueue(const Object & elem){
	
	if(isEmpty()){
		this->countnum = 1;
		this->nodefront->data = elem;
		this->noderear->data = elem;
	}
	else{
		this->countnum += 1;
		node *tempnode = new node;
		tempnode->data = elem;
		this->noderear->next = tempnode;
		this->noderear = tempnode;
	}
}
template<typename Object>
void LLQueue<Object>::dequeue(){
	if(isEmpty()){
		throw QueueEmptyException("It's empty");
	}
	else{
		
		node *newpoint = this->nodefront;
		newpoint = this->nodefront->next;
		delete(nodefront);
		nodefront = newpoint;
		this->countnum -= 1;
		}

}


#endif 
