#include "proj2.hpp"

#include <vector>
#include <iostream>
using namespace std;


void countPaths(const std::vector< std::vector<unsigned> > & friends, unsigned start, std::vector<unsigned> & pathLengths, std::vector<unsigned> & numShortestPaths)
{
    vector<bool> check_sheet(friends.size(),true);
	vector< vector<int> > total_result(friends.size());
	vector<int> the_path;
    for(int i=0;i<friends.size();i++){
        find_path(friends,start,i,check_sheet,the_path,total_result);
        for(int j = 0; j<friends.size();j++){
           check_sheet[j] = true;
        }
    
    }
 



    int minnum;
    for(int i=0;i<total_result.size();i++){
        for(int j = 0;j<total_result[i].size();j++){
            
            if(j == 0){
                minnum = total_result[i][0];
            }
            else{
                if(minnum > total_result[i][j]){
                    minnum = total_result[i][j];
                }
            }
        }
        pathLengths[i] = minnum;
    }
    int countmin;
    for(int i=0;i<total_result.size();i++){
        countmin = 0;
        for(int j = 0;j<total_result[i].size();j++){
            if(pathLengths[i] == total_result[i][j]){
                countmin += 1;
            }
        }
        numShortestPaths[i] = countmin;
    }


}

void find_path(const std::vector< std::vector<unsigned> > & friends, int start_i, int end_i,vector<bool> check_sheet, vector<int> the_path,vector< vector<int> > & total_result){
	if(start_i!=end_i){
		the_path.push_back(start_i);
		check_sheet[start_i] = false;
		for(int i=0; i<friends[start_i].size();i++){
			if(check_sheet[friends[start_i][i]] == true){
				for(int j=0; j<friends[start_i].size();j++){
					if(j != i) check_sheet[friends[start_i][j]] = false;
				}
				find_path(friends, friends[start_i][i], end_i, check_sheet, the_path, total_result);
				check_sheet[friends[start_i][i]] = false;
				for(int j=0; j<friends[start_i].size();j++){
					if(j != i) check_sheet[friends[start_i][j]] = true;
				}
			}
			if(i == friends[start_i].size()-1 && check_sheet[friends[start_i][i]] == false){
				the_path.pop_back();
				return;
			}
		
		}
	}
	else{
		the_path.push_back(end_i);
	//	bool check_state = true;
	//	for(int i = 1; i<the_path.size();i++){
	//		if(the_path[i]<the_path[i-1]){
	//			check_state = false;
	//		} 
	//	}
	//	if(check_state == true){
			total_result[end_i].push_back(the_path.size()-1);
	//	} 
	}
	
}

